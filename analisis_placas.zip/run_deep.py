import cv2 # OpenCV
import numpy as np
import tensorflow as tf

def weight_variable(shape):
    """
    Crea una variable para los pesos de las conecciones entre neuronas con valores aleatorios
    args:
        shape (array): la forma de la red neuronal, cada elemento es el numero de neuronas de cada capa
    return:
        tf.Variable: variable de TensorFlow
    """
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

def bias_variable(shape):
    """
    Crea una variable para el bias de las neuronas con el valor 0.1
    args:
        shape (array): la forma de la red neuronal, cada elemento es el numero de neuronas de cada capa
    return:
        tf.Variable: variable de TensorFlow
    """
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)

def conv2d(x, W):
    """
    Realiza una convolucion 2D dado dos tensores 4D, uno de entrada y uno de filtro
    """
    return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='SAME')

def max_pool_2x2(x):
    """
    Dado el tensor 'x' 4D, realiza un max pooling del cuadrado de 2x2 neuronas
    """
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

def deepnn(x):
    """
    Crea la Deep Neural Network:
      1) Convolutional Neural Network
      2) Convolutional Neural Network
      3) Dropout features
      4) Linear Regresion
    """

    # Dado que el argumento de entrada es un vector de 1x729 elementos
    # Lo redimensionamos a 28x28x1 (el -1 indica que puede ser de cualquier tamanio)
    with tf.name_scope('reshape'):
        x_image = tf.reshape(x, [-1, 28, 28, 1])

    # Primer capa convolucional [CNN (Convolutional Neural Network)]
    # Mapea una imagen de escala de grises a 32 parametros de 28x28
    with tf.name_scope('conv1'):
        W_conv1 = weight_variable([5, 5, 1, 32])
        b_conv1 = bias_variable([32])
        h_conv1 = tf.nn.relu(conv2d(x_image, W_conv1) + b_conv1)

    # Primer capa de 'agrupacion' (Pooling layer) - disminuye la dimension de los
    #       32 parametros a la mitad. 28x28 => 14x14
    with tf.name_scope('pool1'):
        h_pool1 = max_pool_2x2(h_conv1)

    # Segunda capa convolucional [CNN (Convolutional Neural Network)]
    # Mapea 32 parametros de 14x14 a 64 parametros de 14x14
    with tf.name_scope('conv2'):
        W_conv2 = weight_variable([5, 5, 32, 64])
        b_conv2 = bias_variable([64])
        h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2) + b_conv2)

    # Segunda capa de 'agrupacion' (Pooling layer) - disminuye la dimension de los
    #       64 parametros a la mitad. 14x14 => 7x7
    with tf.name_scope('pool2'):
        h_pool2 = max_pool_2x2(h_conv2)

    # Capa completamente conectada (Fully connected layer), mapea nuestros 64
    #       parametros de 7x7 a 1024 parametros lineales (1x1)
    with tf.name_scope('fc1'):
        W_fc1 = weight_variable([7*7*64, 1024])
        b_fc1 = bias_variable([1024])

        # Necesitamos redimensionar nuestros 64 parametros de 7x7 a 64*7*7
        h_pool2_flat = tf.reshape(h_pool2, [-1, 7*7*64])
        h_fc1 = tf.nn.relu(tf.matmul(h_pool2_flat, W_fc1) + b_fc1)

    # Dropout: Controla la complejidad del modelo, previene la co-adaptacion de
    # los parametros
    with tf.name_scope('dropout'):
        keep_prob = tf.placeholder(tf.float32)
        h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

    # Regresion Lineal para mapear los 1024 parametros a los 36 finales (digitos y letras)
    with tf.name_scope('fc2'):
        W_fc2 = weight_variable([1024, 36])
        b_fc2 = bias_variable([36])

        y_conv = tf.matmul(h_fc1_drop, W_fc2) + b_fc2

    return y_conv, keep_prob

########
# Main #
########

# Creamos nuestras entradas a la DNN (28*28 = 784)
x = tf.placeholder(tf.float32, [None, 784])

# Mapeamos clases en letras
char = ['0', '1', '2', '3', '4',
        '5', '6', '7', '8', '9',
        'A', 'B', 'C', 'D', 'E',
        'F', 'G', 'H', 'I', 'J',
        'K', 'L', 'M', 'N', 'O',
        'P', 'Q', 'R', 'S', 'T',
        'U', 'V', 'W', 'X', 'Y',
        'Z']

# Construimos la Deep Neural Network, le pasamos la variable de entrada y nos
#   regresa la salida de la red (y_conv) y la variable para el dropout (keep_prob)
y_conv, keep_prob = deepnn(x)

# Iniciamos una sesion de Tensor Flow
with tf.Session() as sess:
    # Inicializamos todas nuestras variables
    sess.run(tf.global_variables_initializer())
    # Iniciamos la clase Saver para poder restaurar la informacion
    saver = tf.train.Saver()
    # Restauramos la informacion de nuestras variables
    saver.restore(sess, 'variables_myds/var.ckpt')

    # Leemos la imagen
    img = cv2.imread("TestData/num.png")
    # Cambiamos de RGB (OpenCV por default tiene los canales en el orden BGR)
    #   a escala de grises
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # binarizamos la imagen con un umbral de 128
    thresh, img = cv2.threshold(img, 128, 1, cv2.THRESH_BINARY_INV)
    # print np.shape(img)
    # print img
    # Redimencionamos la imagen a 1x784
    input_image = img.reshape(1, 28*28)
    # Corremos la dnn
    output = sess.run(y_conv, feed_dict={x: input_image, keep_prob: 1.0})
    # Obtenemos el indice que corresponde al valor mas alto en nuestro vector
    #   de salidas
    num = tf.argmax(output, 1).eval()[0]
    
    print 'Char:', char[num], '(', num, ')'
    print output
