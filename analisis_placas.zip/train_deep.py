
# EMNIST Dataset
# Cohen, G., Afshar, S., Tapson, J., & van Schaik, A. (2017). EMNIST: an extension of MNIST to
# handwritten letters. Retrieved from http://arxiv.org/abs/1702.05373

# from emnist.emnist import read_data_sets
from EmnistReader.EmnistReader import EmnistReader
import numpy as np
import tensorflow as tf
import sys

def weight_variable(shape):
    """
    Crea una variable para los pesos de las conecciones entre neuronas con valores aleatorios
    args:
        shape (array): la forma de la red neuronal, cada elemento es el numero de neuronas de cada capa
    return:
        tf.Variable: variable de TensorFlow
    """
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

def bias_variable(shape):
    """
    Crea una variable para el bias de las neuronas con el valor 0.1
    args:
        shape (array): la forma de la red neuronal, cada elemento es el numero de neuronas de cada capa
    return:
        tf.Variable: variable de TensorFlow
    """
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)

def conv2d(x, W):
    """
    Realiza una convolucion 2D dado dos tensores 4D, uno de entrada y uno de filtro
    """
    return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='SAME')

def max_pool_2x2(x):
    """
    Dado el tensor 'x' 4D, realiza un max pooling del cuadrado de 2x2 neuronas
    """
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

def deepnn(x):
    """
    Crea la Deep Neural Network:
      1) Convolutional Neural Network
      2) Convolutional Neural Network
      3) Dropout features
      4) Linear Regresion
    """

    # Dado que el argumento de entrada es un vector de 1x729 elementos
    # Lo redimensionamos a 28x28x1 (el -1 indica que puede ser de cualquier tamanio)
    with tf.name_scope('reshape'):
        x_image = tf.reshape(x, [-1, 28, 28, 1])

    # Primer capa convolucional [CNN (Convolutional Neural Network)]
    # Mapea una imagen de escala de grises a 32 parametros de 28x28
    with tf.name_scope('conv1'):
        W_conv1 = weight_variable([5, 5, 1, 32])
        b_conv1 = bias_variable([32])
        h_conv1 = tf.nn.relu(conv2d(x_image, W_conv1) + b_conv1)

    # Primer capa de 'agrupacion' (Pooling layer) - disminuye la dimension de los
    #       32 parametros a la mitad. 28x28 => 14x14
    with tf.name_scope('pool1'):
        h_pool1 = max_pool_2x2(h_conv1)

    # Segunda capa convolucional [CNN (Convolutional Neural Network)]
    # Mapea 32 parametros de 14x14 a 64 parametros de 14x14
    with tf.name_scope('conv2'):
        W_conv2 = weight_variable([5, 5, 32, 64])
        b_conv2 = bias_variable([64])
        h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2) + b_conv2)

    # Segunda capa de 'agrupacion' (Pooling layer) - disminuye la dimension de los
    #       64 parametros a la mitad. 14x14 => 7x7
    with tf.name_scope('pool2'):
        h_pool2 = max_pool_2x2(h_conv2)

    # Capa completamente conectada (Fully connected layer), mapea nuestros 64
    #       parametros de 7x7 a 1024 parametros lineales (1x1)
    with tf.name_scope('fc1'):
        W_fc1 = weight_variable([7*7*64, 1024])
        b_fc1 = bias_variable([1024])

        # Necesitamos redimensionar nuestros 64 parametros de 7x7 a 64*7*7
        h_pool2_flat = tf.reshape(h_pool2, [-1, 7*7*64])
        h_fc1 = tf.nn.relu(tf.matmul(h_pool2_flat, W_fc1) + b_fc1)

    # Dropout: Controla la complejidad del modelo, previene la co-adaptacion de
    # los parametros
    with tf.name_scope('dropout'):
        keep_prob = tf.placeholder(tf.float32)
        h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

    # Regresion Lineal para mapear los 1024 parametros a los 36 finales (digitos y letras)
    with tf.name_scope('fc2'):
        W_fc2 = weight_variable([1024, 36])
        b_fc2 = bias_variable([36])

        y_conv = tf.matmul(h_fc1_drop, W_fc2) + b_fc2

    return y_conv, keep_prob

########
# Main #
########

ds_dir = 'MyDS_data/'
# emnist = read_data_sets(ds_dir, one_hot=True)
emnist = EmnistReader(ds_dir, 'myds', one_hot=True, num_classes=36)

# Creamos nuestras entradas a la DNN (28*28 = 784)
x = tf.placeholder(tf.float32, [None, 784])

# Definimos la variable para guardar las salidas correctas (10 digitos y 26 letras mayusculas)
y_ = tf.placeholder(tf.float32, [None, 36])

# Construimos la Deep Neural Network, le pasamos la variable de entrada y nos
#   regresa la salida de la red (y_conv) y la variable para el dropout (keep_prob)
y_conv, keep_prob = deepnn(x)

# Definimos nuestra funcion de error entre la salida de la red y la respuesta correcta
with tf.name_scope('loss'):
    cross_entropy = tf.reduce_mean(
        tf.nn.softmax_cross_entropy_with_logits(labels=y_, logits=y_conv))

# Definimos nuestro algoritmo para minimizar nuestro error
with tf.name_scope('adam_optimizer'):
    train_step = tf.train.AdamOptimizer(1e-4).minimize(cross_entropy)

# Definimos nuestra funcion para calcular la precision de nuestra deep neural network
with tf.name_scope('accuracy'):
    correct_prediction = tf.equal(tf.argmax(y_conv, 1), tf.argmax(y_, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

# Restore from step
step = 0

# Iniciamos una sesion de Tensor Flow
with tf.Session() as sess:
    # Inicializamos todas nuestras variables
    sess.run(tf.global_variables_initializer())
    # Iniciamos la clase Saver para poder guardar la informacion
    saver = tf.train.Saver()
    if step > 0:
        # Previously
        saver.restore(sess, 'variables_myds/last_one/var.ckpt')
        # Calculamos la posicion de lectura del dataset
        emnist.train.currBatch = (step * 180)%emnist.train.ndata
    # Precargamos 100 pedazos de 180
    emnist.train.preload(100 * 180)
    # Iteramos 20000 veces
    for i in range(step, 20000):
        # Cada iteracion le pasara 180 ejemplos a nuestra dnn
        batch = emnist.train.next_batch(180)
        # Cada 100 iteraciones imprimimos la precision de nuestra dnn
        if i % 100 == 0:
            # El metodo eval ejecuta las funciones que tienen definidas, con sus valores de entrada y de salida correctos
            train_accuracy = accuracy.eval(feed_dict={x: batch[0], y_: batch[1], keep_prob: 1.0})
            print('step %d, training accuracy %g' % (i, train_accuracy))
            saver.save(sess, 'variables_myds/last_one/var.ckpt')
        else:
            print 'step %d ...\r'%i,
            sys.stdout.flush()
        # El metodo run  ejecuta las funciones que tienen definidas, con sus valores de entrada y de salida correctos
        train_step.run(feed_dict={x: batch[0], y_: batch[1], keep_prob: 0.5})

    # Guardamos la informacion de nuestras variables
    saver.save(sess, 'variables_myds/final/var.ckpt')
    # Probamos con 10k datos
    batch = emnist.test.next_batch(10000)
    print('test accuracy %g' % accuracy.eval(feed_dict={x: batch[0], y_: batch[1], keep_prob: 1.0}))

