
import gzip
import numpy as np
import struct

from DataSet import DataSet

class DataType:
    """
    Data Type Enum
    """
    UBYTE   = 0x08
    BYTE    = 0x09
    SHORT   = 0x0B
    INT     = 0x0C
    FLOAT   = 0x0D
    DOUBLE  = 0x0E

class EmnistReader:
    """
    EMNIST Dataset Reader
    """
    def __init__(self,
                 ds_dir,
                 dataset,
                 one_hot=False,
                 dtype=np.float32,
                 reshape=True,
                 num_classes=47):
        self.ds_dir = ds_dir
        self.dataset = dataset

        train_images_file = self.ds_dir + self.dataset + '-train-images-idx3-ubyte.gz'
        train_labels_file = self.ds_dir + self.dataset + '-train-labels-idx1-ubyte.gz'
        test_images_file = self.ds_dir + self.dataset + '-test-images-idx3-ubyte.gz'
        test_labels_file = self.ds_dir + self.dataset + '-test-labels-idx1-ubyte.gz'

        options = dict(one_hot=one_hot, dtype=dtype, reshape=reshape, num_classes=num_classes)

        self.train = DataSet(train_images_file, train_labels_file, **options)
        if self.train.ndata == None:
            return
        self.test = DataSet(test_images_file, test_labels_file, **options)
        if self.test.ndata == None:
            return

        if self.train.rows != self.test.rows or self.train.cols != self.test.cols:
            print('Different image shapes.')
            self.train = None
            self.test = None
            return

    @staticmethod
    def mergeDatasets(DSList, fileout='mergeOut.gz'):
        """
        Merge the datasets in DSList to a single file 'fileout'
        """
        N = len(DSList)
        file = [None] * N
        num = [None] * N
        file[0] = gzip.open(DSList[0])
        header = struct.unpack('>4B', file[0].read(4))
        if header[0] != 0 or header[1] != 0:
            file[0].close()
            print 'Invalid file "%s".'%DSList[0]
            return
        datatype = header[2]
        dimensions = header[3]
        num[0] = struct.unpack('>I', file[0].read(4))[0]
        shape = []
        datalen = 1
        for i in range(1, dimensions):
            dim = struct.unpack('>I', file[0].read(4))[0]
            shape.append(dim)
            datalen *= dim

        for i in range(1, N):
            file[i] = gzip.open(DSList[i])
            header = struct.unpack('>4B', file[i].read(4))
            if header[0] != 0 or header[1] != 0:
                for j in range(0, i+1):
                    file[j].close()
                print 'Invalid file "%s".'%DSList[i]
                return
            if datatype != header[2]:
                for j in range(0, i+1):
                    file[j].close()
                print 'File "%s" has different data type.'%DSList[i]
                return
            if dimensions != header[3]:
                for j in range(0, i+1):
                    file[j].close()
                print 'File "%s" has different number of data dimension.'%DSList[i]
                return
            num[i] = struct.unpack('>I', file[i].read(4))[0]
            for j in range(1, dimensions):
                dim = struct.unpack('>I', file[i].read(4))[0]
                if dim != shape[j-1]:
                    for k in range(0, i+1):
                        file[k].close()
                    print 'File "%s" has different data shape.'%DSList[i]
                    return

            # Create the new file
            fout = gzip.open(fileout, 'wb')
            magic = '\x00\x00'
            magic += struct.pack('>B', datatype)
            magic += struct.pack('>B', dimensions)
            fout.write(magic)
            fout.write(struct.pack('>I', sum(num)))
            if shape:
                for sh in shape:
                    fout.write(struct.pack('>I', sh))
                for i in range(N):
                    fout.write(file[i].read(num[i] * datalen))
            else:
                maxval = -1
                for i in range(N):
                    oldmax = maxval
                    for j in range(num[i]):
                        data = file[i].read(1)
                        value = struct.unpack('>B', data)[0]
                        if value > maxval:
                            maxval = value
                        fout.write(struct.pack('>B', value + oldmax + 1))


            fout.close()
            for i in range(N):
                file[i].close()
