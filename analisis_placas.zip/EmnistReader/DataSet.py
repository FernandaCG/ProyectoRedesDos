
import gzip
import numpy as np
import struct

class DataSet:
    def __init__(self,
                 img_filename,
                 lbl_filename,
                 one_hot=False,
                 dtype=np.float32,
                 reshape=True,
                 num_classes=47):
        self.img_filename = img_filename
        self.lbl_filename = lbl_filename
        self.one_hot = one_hot
        self.dtype = dtype
        self.reshape = reshape
        self.num_classes = num_classes
        self.currBatch = 0
        self.ndata = None
        self.preload_size = 0
        self.imgsPre = None
        self.lblsPre = None

        fimg = gzip.open(self.img_filename)
        flbl = gzip.open(self.lbl_filename)

        # Read Magic Number
        # The magic number is an integer (MSB first)
        magic = struct.unpack('>I', fimg.read(4))[0]
        if magic != 2051:
            fimg.close()
            flbl.close()
            print 'Invalid file "%s".'%self.img_filename
            return

        magic = struct.unpack('>I', flbl.read(4))[0]
        if magic != 2049:
            fimg.close()
            flbl.close()
            print 'Invalid file "%s".'%self.lbl_filename
            return

        # The sizes in each dimension are 4-byte integers (MSB first)
        self.ndata = struct.unpack('>I', fimg.read(4))[0]
        self.rows = struct.unpack('>I', fimg.read(4))[0]
        self.cols = struct.unpack('>I', fimg.read(4))[0]
        self.pixels = self.rows * self.cols

        ndata = struct.unpack('>I', flbl.read(4))[0]

        if self.ndata != ndata:
            print('Different quantity of data. (%s vs %s)'%(self.img_filename, self.lbl_filename))
            self.ndata = None
            return

        fimg.close()
        flbl.close()

    def next_batch(self, num):
        """
        Read 'num' chunks of data
        """
        if self.preload_size > 0:
            if len(self.imgsPre) < num:
                self.currBatch = (self.currBatch + self.ndata - len(self.imgsPre))%self.ndata
                self.preload(self.preload_size)
            imgs = self.imgsPre[:num]
            lbls = self.lblsPre[:num]
            self.imgsPre = self.imgsPre[num:]
            self.lblsPre = self.lblsPre[num:]
        else:
            if self.currBatch + num > self.ndata:
                f_part = self.ndata - self.currBatch
                s_part = num - f_part
                with gzip.open(self.img_filename) as f:
                    # Go to the current data
                    f.seek(16 + self.currBatch * self.pixels, 0)
                    # Read the first part
                    data = f.read(f_part * self.pixels)
                    # Go to the beginning
                    f.seek(16, 0)
                    # Read the second part
                    data += f.read(s_part * self.pixels)

                    # Bytes to array [np.uint8]
                    imgs = np.asarray(bytearray(data), dtype=np.uint8)
                    # Transpose
                    imgs = np.transpose(imgs.reshape((num, self.rows, self.cols)), (0, 2, 1))
                    # Reshape
                    if self.reshape:
                        imgs = imgs.reshape(num, 28*28)
                    # Convert from [0, 255] => [0.0, 1.0]
                    if self.dtype == np.float32:
                        imgs = imgs.astype(np.float32)
                        imgs = np.multiply(imgs, 1.0 / 255.0)

                with gzip.open(self.lbl_filename) as f:
                    # Go to the current data
                    f.seek(8 + self.currBatch, 0)
                    # Read the first part
                    data = f.read(f_part)
                    # Go to the beginning
                    f.seek(8, 0)
                    # Read the second part
                    data += f.read(s_part)

                    # Bytes to array
                    lbls = np.asarray(bytearray(data), dtype=np.uint8)
                    # Convert class labels from scalars to one-hot vectors
                    if self.one_hot:
                        idx_offset = np.arange(num) * self.num_classes
                        lbl_one_hot = np.zeros((num, self.num_classes))
                        lbl_one_hot.flat[idx_offset + lbls.ravel()] = 1
                        lbls = lbl_one_hot

                self.currBatch = s_part
            else:
                with gzip.open(self.img_filename) as f:
                    # Go to the current data
                    f.seek(16 + self.currBatch * self.pixels, 0)
                    # Read the data
                    data = f.read(num * self.pixels)

                    # Bytes to array [np.uint8]
                    imgs = np.asarray(bytearray(data), dtype=np.uint8)
                    # Transpose
                    imgs = np.transpose(imgs.reshape((num, self.rows, self.cols)), (0, 2, 1))
                    # Reshape
                    if self.reshape:
                        imgs = imgs.reshape(num, 28*28)
                    # Convert from [0, 255] => [0.0, 1.0]
                    if self.dtype == np.float32:
                        imgs = imgs.astype(np.float32)
                        imgs = np.multiply(imgs, 1.0 / 255.0)

                with gzip.open(self.lbl_filename) as f:
                    # Go to the current data
                    f.seek(8 + self.currBatch, 0)
                    # Read the first part
                    data = f.read(num)

                    # Bytes to array
                    lbls = np.asarray(bytearray(data), dtype=np.uint8)
                    # Convert class labels from scalars to one-hot vectors
                    if self.one_hot:
                        idx_offset = np.arange(num) * self.num_classes
                        lbl_one_hot = np.zeros((num, self.num_classes))
                        lbl_one_hot.flat[idx_offset + lbls.ravel()] = 1
                        lbls = lbl_one_hot

                self.currBatch = (self.currBatch + num)%self.ndata

        return imgs, lbls

    def getAll(self):
        """
        Get all the data from the files
        """
        self.currBatch = 0
        return self.next_batch(self.ndata)

    def preload(self, size):
        self.preload_size = 0
        self.imgsPre, self.lblsPre = self.next_batch(size)
        self.preload_size = size
