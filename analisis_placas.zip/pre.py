#!/usr/bin/env python

from os import listdir
from copy import deepcopy
import cv2

# Obtenemos todas las imagenes de la carpeta data
dataset = listdir('data')

WI, HI = 512, 256 # Width, Height
MIN_H, MAX_H = 0.33*HI, 0.51*HI # Altura Minima/Maxima
MIN_AREA, MAX_AREA = 0.04*WI * MIN_H * 0.52, 0.1*WI * MAX_H * 0.64 # Area Minima/Maxima
MIN_Y, MAX_Y = 0.2*HI, 0.4*HI # Coordenada Y Minima/Maxima
OFFSET = 10 # Offset a agregar al caracter de la placa

# Recorremos las imagenes
for data in dataset:
    # Leer la imagen
    img = cv2.imread('data/'+data)

    # Redimencionamos la imagen a WI x HI
    img = cv2.resize(img, (WI, HI))
    img_show = deepcopy(img) # Copiamos los valores a otra variable

    # Escala de grises
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Binarizacion de imagen
    thresh, img = cv2.threshold(img, 96, 255, cv2.THRESH_BINARY)
    img_thresh = deepcopy(img)

    # Obtenemos todos los contornos de la imagen binarizada
    contours, hierarchy = cv2.findContours(img, cv2.cv.CV_RETR_TREE, cv2.cv.CV_CHAIN_APPROX_SIMPLE)
    rect = []
    # De todos los contornos
    for i in range(len(contours)):
        # Obtenemos su area
        area = cv2.contourArea(contours[i])
        # Filtramos por area
        if area > MIN_AREA and area < MAX_AREA:
            # Obtenemos el rectangulo envolvente al contorno
            x, y, w, h = cv2.boundingRect(contours[i])
            # Filtramos por la coordenada Y y por la altura
            if y > MIN_Y and y < MAX_Y and h > MIN_H and h < MAX_H:
                # Guardamos el rectangulo
                rect.append([(x, y), (x+w, y+h)])
                # Y dibujamos un rectangulo en la imagen original
                cv2.rectangle(img_show, (x, y), (x+w, y+h), (0, 0, 255))

    if len(rect) != 6:
        print 'Encontrados %d caracteres en la placa.'%len(rect)
        # continue

    # Mostramos la imagen que queremos mostrar
    cv2.imshow('image', img_show)
    # Por cada rectangulo envolvente
    for i in range(len(rect)):
        (x, y), (x2, y2) = rect[i]
        # Obtenemos la Region Of Image con un offset a los lados
        roi = img_thresh[y-OFFSET:y2+OFFSET, x-OFFSET:x2+OFFSET]
        # Redimencionamos a 28x28
        roi = cv2.resize(roi, (28,28))
        # Guardamos la imagen
        cv2.imwrite('char%d.png'%i, roi)

    # Esperamos por una tecla presionada
    cv2.waitKey(0)
    # Borramos todas las ventanas
    cv2.destroyAllWindows()
