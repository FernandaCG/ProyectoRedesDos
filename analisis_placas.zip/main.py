#!/usr/bin/env python

from os import listdir
from copy import deepcopy
import cv2
import numpy as np
import tensorflow as tf

#######################
# Deep Neural Network #
#######################
def weight_variable(shape):
    """
    Crea una variable para los pesos de las conecciones entre neuronas con valores aleatorios
    args:
        shape (array): la forma de la red neuronal, cada elemento es el numero de neuronas de cada capa
    return:
        tf.Variable: variable de TensorFlow
    """
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial)

def bias_variable(shape):
    """
    Crea una variable para el bias de las neuronas con el valor 0.1
    args:
        shape (array): la forma de la red neuronal, cada elemento es el numero de neuronas de cada capa
    return:
        tf.Variable: variable de TensorFlow
    """
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial)

def conv2d(x, W):
    """
    Realiza una convolucion 2D dado dos tensores 4D, uno de entrada y uno de filtro
    """
    return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='SAME')

def max_pool_2x2(x):
    """
    Dado el tensor 'x' 4D, realiza un max pooling del cuadrado de 2x2 neuronas
    """
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

def deepnn(x):
    """
    Crea la Deep Neural Network:
      1) Convolutional Neural Network
      2) Convolutional Neural Network
      3) Dropout features
      4) Linear Regresion
    """

    # Dado que el argumento de entrada es un vector de 1x729 elementos
    # Lo redimensionamos a 28x28x1 (el -1 indica que puede ser de cualquier tamanio)
    with tf.name_scope('reshape'):
        x_image = tf.reshape(x, [-1, 28, 28, 1])

    # Primer capa convolucional [CNN (Convolutional Neural Network)]
    # Mapea una imagen de escala de grises a 32 parametros de 28x28
    with tf.name_scope('conv1'):
        W_conv1 = weight_variable([5, 5, 1, 32])
        b_conv1 = bias_variable([32])
        h_conv1 = tf.nn.relu(conv2d(x_image, W_conv1) + b_conv1)

    # Primer capa de 'agrupacion' (Pooling layer) - disminuye la dimension de los
    #       32 parametros a la mitad. 28x28 => 14x14
    with tf.name_scope('pool1'):
        h_pool1 = max_pool_2x2(h_conv1)

    # Segunda capa convolucional [CNN (Convolutional Neural Network)]
    # Mapea 32 parametros de 14x14 a 64 parametros de 14x14
    with tf.name_scope('conv2'):
        W_conv2 = weight_variable([5, 5, 32, 64])
        b_conv2 = bias_variable([64])
        h_conv2 = tf.nn.relu(conv2d(h_pool1, W_conv2) + b_conv2)

    # Segunda capa de 'agrupacion' (Pooling layer) - disminuye la dimension de los
    #       64 parametros a la mitad. 14x14 => 7x7
    with tf.name_scope('pool2'):
        h_pool2 = max_pool_2x2(h_conv2)

    # Capa completamente conectada (Fully connected layer), mapea nuestros 64
    #       parametros de 7x7 a 1024 parametros lineales (1x1)
    with tf.name_scope('fc1'):
        W_fc1 = weight_variable([7*7*64, 1024])
        b_fc1 = bias_variable([1024])

        # Necesitamos redimensionar nuestros 64 parametros de 7x7 a 64*7*7
        h_pool2_flat = tf.reshape(h_pool2, [-1, 7*7*64])
        h_fc1 = tf.nn.relu(tf.matmul(h_pool2_flat, W_fc1) + b_fc1)

    # Dropout: Controla la complejidad del modelo, previene la co-adaptacion de
    # los parametros
    with tf.name_scope('dropout'):
        keep_prob = tf.placeholder(tf.float32)
        h_fc1_drop = tf.nn.dropout(h_fc1, keep_prob)

    # Regresion Lineal para mapear los 1024 parametros a los 36 finales (digitos y letras)
    with tf.name_scope('fc2'):
        W_fc2 = weight_variable([1024, 36])
        b_fc2 = bias_variable([36])

        y_conv = tf.matmul(h_fc1_drop, W_fc2) + b_fc2

    return y_conv, keep_prob

############################
# ANALISIS IMAGENES PLACAS #
############################

# Obtenemos todas las imagenes de la carpeta data
dataset = listdir('TestData')

WI, HI = 512, 256 # Width, Height
MIN_H, MAX_H = 0.33*HI, 0.51*HI # Altura Minima/Maxima
MIN_AREA, MAX_AREA = 0.04*WI * MIN_H * 0.52, 0.1*WI * MAX_H * 0.64 # Area Minima/Maxima
MIN_Y, MAX_Y = 0.2*HI, 0.4*HI # Coordenada Y Minima/Maxima
OFFSET = 10 # Offset a agregar al caracter de la placa

# Inicializamos nuestra DNN
# Creamos nuestras entradas a la DNN (28*28 = 784)
input_image = tf.placeholder(tf.float32, [None, 784])

# Mapeamos clases en letras
char = ['0', '1', '2', '3', '4',
        '5', '6', '7', '8', '9',
        'A', 'B', 'C', 'D', 'E',
        'F', 'G', 'H', 'I', 'J',
        'K', 'L', 'M', 'N', 'O',
        'P', 'Q', 'R', 'S', 'T',
        'U', 'V', 'W', 'X', 'Y',
        'Z']

# Construimos la Deep Neural Network, le pasamos la variable de entrada y nos
#   regresa la salida de la red (y_conv) y la variable para el dropout (keep_prob)
y_conv, keep_prob = deepnn(input_image)

# Iniciamos una sesion de Tensor Flow
with tf.Session() as sess:
    # Inicializamos todas nuestras variables
    sess.run(tf.global_variables_initializer())
    # Iniciamos la clase Saver para poder restaurar la informacion
    saver = tf.train.Saver()
    # Restauramos la informacion de nuestras variables
    saver.restore(sess, 'variables_myds/var.ckpt')

    # Recorremos las imagenes
    for data in dataset:
        if data == 'num.png':
            continue
        # Leer la imagen
        img = cv2.imread('TestData/'+data)

        # Redimencionamos la imagen a WI x HI
        img = cv2.resize(img, (WI, HI))
        img_show = deepcopy(img) # Copiamos los valores a otra variable

        # Escala de grises
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img_gray = deepcopy(img)

        # Binarizacion de imagen
        thresh, img = cv2.threshold(img, 96, 1, cv2.THRESH_BINARY_INV)

        # Obtenemos todos los contornos de la imagen binarizada
        img_con, contours, hierarchy = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        rect = []
        # De todos los contornos
        for i in range(len(contours)):
            # Obtenemos el rectangulo envolvente al contorno
            x, y, w, h = cv2.boundingRect(contours[i])
            # Filtramos por la coordenada Y y por la altura
            if y > MIN_Y and y < MAX_Y and h > MIN_H and h < MAX_H:
                # Guardamos el rectangulo
                rect.append([(x, y), (w, h)])
                # Y dibujamos un rectangulo en la imagen original
                cv2.rectangle(img_show, (x, y), (x+w, y+h), (0, 0, 255), 2)
        # Ordenamos los rectangulos
        rect.sort()

        if len(rect) != 6:
            print 'Encontrados %d caracteres en la placa.'%len(rect)
            # continue

        # Mostramos la imagen con los contornos
        cv2.imshow('image', img_show)
        # Valor de la placa
        pl = ''
        # Por cada rectangulo envolvente
        for i in range(len(rect)):
            (x, y), (w, h) = rect[i]
            # Inicializamos la ROI
            roi = np.zeros((h+2*OFFSET, h+2*OFFSET), dtype=np.uint8)
            # Obtenemos la correcion en el eje horizontal
            cor = (h-w)/2 + (h-w)%2 + OFFSET
            # Obtenemos la Region Of Image
            roi[OFFSET:h+OFFSET, cor:cor+w] = img[y:y+h, x:x+w]
            # Redimencionamos a 28x28
            roi = cv2.resize(roi, (28,28))
            # Convertimos la imagen a una lineal
            roi = roi.reshape(1, 28*28)
            # Obtenemos la salida de la dnn
            output = sess.run(y_conv, feed_dict={input_image: roi, keep_prob: 1.0})
            num = tf.argmax(output, 1).eval()[0]
            pl += char[num]

        # Mostramos la placa
        print pl
        # Esperamos por una tecla presionada
        cv2.waitKey(0)
        # Borramos todas las ventanas
        cv2.destroyAllWindows()
